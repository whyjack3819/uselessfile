# Instagram DM bot

Instagram DM bot with account switcher feature. This bot can send messages automatically in your list of usernames.
It will send DMs and switch account automatically. It will switch account every 10 messages, so this means it will
change account after it sends message to 10 usernames and then it will go to the next account.

## Setup Bot

1.  Git clone this repo with this command --> `git clone https://github.com/redianmarku/ig-dmbot-acc`
2.  Install requirements with this command --> `pip install -r requirements.txt`
3.  Open infos folder and fill your infos of accounts in accounts.json file, in messages.txt put your message list and
    in usernames.txt put you username list that you want to send dm.
4.  Run the bot with this command --> `python run.py`

## Donate Here: PayPal --> https://paypal.me/redidev.

Thank You!
